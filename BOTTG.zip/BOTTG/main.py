from flask import Flask
import requests

app = Flask(__name__)

BOT_TOKEN = "8085146671:AAGEvGtGca2mWQeqxx0kRI_bm3SOnzUyWdE"
CHAT_IDS = ["-4677270731"]  # Sem môžeš pridať ďalšie skupiny napr. ["id1", "id2"]
PHOTO_PATH = "free.png"

CAPTION = """FREE SFS🙏
Message: @ofm_daniel
5K SUBS ♥ TOP CREATOR"""

def send_photo():
    for chat_id in CHAT_IDS:
        with open(PHOTO_PATH, 'rb') as photo:
            data = {'chat_id': chat_id, 'caption': CAPTION}
            files = {'photo': photo}
            response = requests.post(
                f"https://api.telegram.org/bot{BOT_TOKEN}/sendPhoto",
                data=data,
                files=files
            )
            print(response.json())

@app.route('/')
def home():
    send_photo()
    return "📸 Fotka bola odoslaná!"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)